// JS for settings.html
console.log("settings");