// JS for index.html
console.log("welcome page");