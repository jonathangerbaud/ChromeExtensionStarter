// JS for popup.html
console.log("popup");