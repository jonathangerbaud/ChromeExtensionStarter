// JS for index.html
console.log("index page");